from page_loader2.page_loader import download

__all__ = ['download']
